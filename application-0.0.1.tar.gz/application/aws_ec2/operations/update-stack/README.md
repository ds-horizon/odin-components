## Update stack operation

Update the number of application stacks

### Update stack operation schema

#### Properties

| Property      | Type    | Required | Description          |
|---------------|---------|----------|----------------------|
| `stacks`      | integer | **Yes**  | New number of stacks |
| `autoRouting` | boolean | No       |                      |


