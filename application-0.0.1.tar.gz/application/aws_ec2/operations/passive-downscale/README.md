## Passive Downscale operation

Finds and downscales the passive stack

### Passive downscale operation schema

| Property | Type | Required | Description |
|----------|------|----------|-------------|


